# -*- coding: utf-8 -*-
TOKEN = "724723234:AAGXh0f2DtqjaIZgXp70NZ-XZTOo5icl27c"
ADMIN = 643923623

enabled_plugins = [
"admins",
"restrict_joined",
"callback_data",
"banned",
"helpers",
"joiningbot",
"message_handler",
"anti_link",
]