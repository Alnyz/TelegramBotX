RESTRICTIONS =  "*Restricted helper's*\nuse '/' or not for prefix\nUsage: /restrict <off/on>" \
							"\nStatus: *{}*\n\nimportant:\n_if the status is True, the restrictions for new members in this group will be active._" 
NO_ACCESS = "i've no Access to do that, or u are not Privileged to admin."
BANNED_HELP = "*Banned Helper's*\nuse '/' or not for prefix\nUsage:\n/kick <time>\n" \
							"/banlist : see banned list\n/unban <number of user>" \
							"\n\nNote:\n_Only admin can kick and unban.\nThe time is optional,default 10 minutes.\nReply to message wich u want to kick._"
BOT_JOIN = ""
HELPER_NOLINK = "*Anti Link Herlper's*\nuse '/' or not for prefix\nUsage: /nolink <on/off>\nStatus: *{}*\n\nimportant:\n_if status is True, anyone cannot send link to this group except Admin and Bot_"
RESET_STATUS = "do you really think want to do that?\n*be aware! this can reset status from group to default*"